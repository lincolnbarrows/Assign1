package assignments.mobilecomputing.com.assignment1;

import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {


    private Thread t;

    private SensorService myservice;
    private FragmentMethod1 fragment1 = new FragmentMethod1();
    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.navigation_method1:
                    pushFragment(new FragmentMethod1());
                    return true;
                case R.id.navigation_method2:
                    pushFragment(new FragmentMethod2());
                    return true;
            }
            return false;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //default fragment set on start of the application
        pushFragment(new FragmentMethod1());


        //bind a service to the main activity
        Intent myIntent;
        myIntent = new Intent(this,SensorService.class);
        bindService(myIntent, myServiceConnection, BIND_AUTO_CREATE);
        Toast.makeText(getApplicationContext(), "bound", Toast.LENGTH_SHORT).show();



        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);


    }

    //method to attach fragment method 1
    private void pushFragment(FragmentMethod1 fragment){
        if(fragment == null){
            return;
        }

        FragmentManager fragmentManager = getSupportFragmentManager();
        if (fragmentManager!=null){

            FragmentTransaction transaction = fragmentManager.beginTransaction();
            transaction.replace(R.id.rootLayout,fragment);
            transaction.commit();
        }
    }

    //method to attach fragment method 2
    private void pushFragment(FragmentMethod2 fragment){
        if(fragment == null){
            return;
        }

        FragmentManager fragmentManager = getSupportFragmentManager();
        if (fragmentManager!=null){

            FragmentTransaction transaction = fragmentManager.beginTransaction();
            transaction.replace(R.id.rootLayout,fragment);
            transaction.commit();
        }
    }

    private ServiceConnection myServiceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            myservice = ((SensorService.MyBinder) iBinder).getService();
        }

        @Override
        public void onServiceDisconnected(ComponentName componentName) {

        }
    };
    public void showAcceleromtrData()
    {
        double[] accelVal;
        accelVal= myservice.getCurrentXYZ();
        //acclx_.setText(new Float(accelVal[0]).toString());
        //accly_.setText(new Float(accelVal[1]).toString());
        //acclz_.setText(new Float(accelVal[2]).toString());
    }
//    public double[] showLocationData()
//    {
//        return myservice.getCurrentLocation();
//
//
//    }



}
