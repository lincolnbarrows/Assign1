package assignments.mobilecomputing.com.assignment1;


import android.Manifest;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.IBinder;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import static android.content.Context.BIND_AUTO_CREATE;


/**
 * A simple {@link Fragment} subclass.
 */
public class FragmentMethod1 extends Fragment implements View.OnClickListener {


    private Button BtnGetLocGPS,BtnGetLocNtwk;
    private EditText editTextlat_, editTextlong_;
    private SensorService myservice;
    private Thread t;

    private SensorManager sensorManager_;
    private Sensor accelerometer_;

    private double x_, y_, z_, latitude, longitude;
    double[] accel_arr = new double[3];
    double[] loc_arr = new double[2];

    public FragmentMethod1() {
        // Required empty public constructor
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View myview = inflater.inflate(R.layout.fragment_method1, container, false);

        myservice = new SensorService((MainActivity)this.getActivity());
        BtnGetLocGPS = (Button) myview.findViewById(R.id.buttonGetLocationGPS);
        BtnGetLocGPS.setOnClickListener((View.OnClickListener) this);
        BtnGetLocNtwk = (Button) myview.findViewById(R.id.buttonGetLocationNTW);
        BtnGetLocNtwk.setOnClickListener((View.OnClickListener) this);

        editTextlat_ = (EditText) myview.findViewById(R.id.latitude);
        editTextlong_ = (EditText) myview.findViewById(R.id.longitude);

        getLocationByNet();
        return myview;

    }

    @Override
    public void onResume() {
        super.onResume();
        getLocationByNet();
    }

    @Override
    public void onClick(View view) {
        switch(view.getId()){
            case R.id.buttonGetLocationGPS:
                getLocationByGPS();
                break;

            case R.id.buttonGetLocationNTW:
                getLocationByNet();
                break;
        }
    }

    public void getLocationByGPS(){
        Location gpsLocation = myservice.getLocation(LocationManager.GPS_PROVIDER);
        if (gpsLocation != null) {
            loc_arr[0] = gpsLocation.getLatitude();
            loc_arr[1] = gpsLocation.getLongitude();
            editTextlat_.setText(new Double(loc_arr[0]).toString());
            editTextlong_.setText(new Double(loc_arr[1]).toString());
        } else {
            //show a toast here saying gps not enabled!!! showSettingsAlert("GPS");
        }
    }

    public void getLocationByNet(){
        Location networkLocation = myservice.getLocation(LocationManager.NETWORK_PROVIDER);
        if (networkLocation != null) {
            loc_arr[0] = networkLocation.getLatitude();
            loc_arr[1] = networkLocation.getLongitude();
            editTextlat_.setText(new Double(loc_arr[0]).toString());
            editTextlong_.setText(new Double(loc_arr[1]).toString());
        } else {
            //show a toast here saying network not enabled!!! showSettingsAlert("Network");
        }
    }


}
