package assignments.mobilecomputing.com.assignment1;

import android.Manifest;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Binder;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.widget.Toast;

public class SensorService extends Service implements SensorEventListener, LocationListener {

    public SensorService() {
    }

    public SensorService(Context context) {
        locationManager = (LocationManager) context
                .getSystemService(LOCATION_SERVICE);
        mContext = context;
    }

    //object of MyBinder
    private MyBinder serviceBinder = new MyBinder();
    private Handler myhandler_ = new Handler();
    private Context mContext;
    private SensorManager sensorManager_;
    private Sensor accelerometer_;
    private LocationManager locationManager;
    private double x_, y_, z_, latitude, longitude;
    double[] accel_arr = new double[3];
    double[] loc_arr = new double[2];
    private Location location;

    private static final long MIN_DISTANCE_FOR_UPDATE = 0;
    private static final long MIN_TIME_FOR_UPDATE = 0;





    /*private class LocationWork implements Runnable {
        public double lat, lon;

        public LocationWork(double lat_, double long_) {
            lat = lat_;
            lon = long_;
        }

        @Override
        public void run() {
            loc_arr[0] = lat;
            loc_arr[1] = lon;
        }
    }

    public double[] getCurrentLocation() {

        return (loc_arr);
    }*/


    private class AccelerationWork implements Runnable {

        private double x, y, z;

        public AccelerationWork(double x_, double y_, double z_) {
            x = x_;
            y = y_;
            z = z_;
        }

        @Override
        public void run() {

            accel_arr[0] = x;
            accel_arr[1] = y;
            accel_arr[2] = z;
        }
    }

    public double[] getCurrentXYZ() {

        return (accel_arr);
    }


    @Override
    public void onCreate() {
        super.onCreate();

        sensorManager_ = (SensorManager) getSystemService(SENSOR_SERVICE);
        accelerometer_ = sensorManager_.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        sensorManager_.registerListener(this, accelerometer_, SensorManager.SENSOR_DELAY_NORMAL);

    }

    public Location getLocation(String provider) {

        if (locationManager.isProviderEnabled(provider)) {

            if (ActivityCompat.checkSelfPermission((MainActivity)mContext, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                    && ActivityCompat.checkSelfPermission((MainActivity)mContext, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                return null;
            }
            locationManager.requestLocationUpdates(provider, MIN_TIME_FOR_UPDATE, MIN_DISTANCE_FOR_UPDATE, this);
            if (locationManager != null) {
                location = locationManager.getLastKnownLocation(provider);
                return location;
            }
        }
        return null;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return serviceBinder;
    }

    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {
        if(sensorEvent.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {

            //extract data from sensors
            x_ = sensorEvent.values[0];
            y_ = sensorEvent.values[1];
            z_ = sensorEvent.values[2];

            //send them for further processing i.e. storing and calculating mean
            AccelerationWork accelWork = new AccelerationWork(x_,y_,z_);
            myhandler_.post(accelWork);
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }

    @Override
    public void onLocationChanged(Location location) {
    }

    @Override
    public void onStatusChanged(String s, int i, Bundle bundle) {

    }

    @Override
    public void onProviderEnabled(String s) {

    }

    @Override
    public void onProviderDisabled(String s) {

    }

    public class MyBinder extends Binder {
        SensorService getService(){
            return SensorService.this;
        }
    }
}
